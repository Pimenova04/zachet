-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 28 2024 г., 09:07
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `article`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `heading` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `heading`, `content`, `author`) VALUES
(1, 'ЭкоО-дизайн: будущее устойчивой моды', 'Эко-дизайн становится основным направлением в индустрии моды, стремящейся минимизировать загрязнение и перерабатывать материалы. Бренды становятся более сознательными в выборе тканей, применяя переработанные и органические материалы.', 'Анна Смирнова'),
(2, 'Как цифровые технологии меняют образование', 'Цифровизация образования открывает новые горизонты для студентов и преподавателей. Виртуальные классы, онлайн-курсы и образовательные платформы обеспечивают доступ к знаниям всем желающим.', 'Иван Петров'),
(3, 'Влияние искусственного интеллекта на рынок труда', 'Искусственный интеллект трансформирует рынок труда, автоматизируя рутинные задачи и создавая новые рабочие места. Однако это также вызывает опасения по поводу увольнений и необходимости переквалификации работников.', 'Екатерина Васильева'),
(4, 'Здоровое питание: мифы и реальность', 'Вокруг здорового питания существует множество мифов. Основные принципы включают разнообразие, умеренность и баланс. Употребление свежих овощей и фруктов, а также отказ от переработанных продуктов способствуют улучшению здоровья.\r\n', 'Олег Кузнецов'),
(5, 'Путешествия в эпоху пандемии: новые правила и тенденции', 'Пандемия COVID-19 значимо повлияла на сферы туризма и гостиничного сервиса. Новые нормы безопасности, ограничение на число путешественников и использование цифровых технологий устанавливают новые правила для путешествий.', 'София Смирнова');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(2, 'admin', '12345', 'admin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
